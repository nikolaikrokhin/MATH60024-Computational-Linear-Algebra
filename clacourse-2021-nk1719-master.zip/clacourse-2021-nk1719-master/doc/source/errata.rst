.. default-role:: math

==================
Errata for 2021/22
==================

Here we'll list all the updates to the exercises and coursework Classroom
repositories for Autumn 2021. An up to date version is in the
`public repository <https://github.com/comp-lin-alg/comp-lin-alg-course>`_.
